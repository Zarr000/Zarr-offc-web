const global = {
    owner: [7822996621], // ganti jadi id mu
    botToken: "8074494110:AAHIyh73n8tKcz0JJBUUU84f_6CP8xW-500", //isi make token bot mu
}

module.exports = global;